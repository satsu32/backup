use yataberyouhin;

INSERT INTO purchase_history_info(user_id, product_id,count, insert_date)
VALUES
("f", "7",1, NOW());