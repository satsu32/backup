use yataberyouhin;

insert into cart_info(user_id, product_id,count, insert_date) values("f", 1,1, NOW());