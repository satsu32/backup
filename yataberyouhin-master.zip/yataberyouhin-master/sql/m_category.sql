use yataberyouhin;

insert into m_category values
(1,2,"本","様々な本に関するカテゴリー",cast('2017-12-05' as date),cast('2017-12-05' as date)),
(2,3,"家電・パソコン","家電とパソコンに関するカテゴリー",cast('2017-12-05' as date),cast('2017-12-05' as date)),
(3,4,"おもちゃ・ゲーム","おもちゃとゲームに関するカテゴリー",cast('2017-12-05' as date),cast('2017-12-05' as date));
