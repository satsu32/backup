use yataberyouhin;

INSERT INTO destination_info(user_id, family_name, first_name, family_name_kana, first_name_kana, email, tel_number, user_address, insert_date)
VALUES
("f", "谷田部", "拓朗", "やたべ", "たくろう", "yatabe@yatabe.com", "080-9090-9090", "東京", NOW()),
("f", "谷田部", "父", "やたべ", "ちち", "father@yatabe.com", "080-9090-0909", "京都", NOW());