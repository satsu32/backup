package com.internousdev.yataberyouhin.util;

/**
 * 入力エラーをまとめて管理
 * @author internousdev
 *
 */
public abstract interface ErrorMessageConstants {

	public static final String FAMILY_NAME_ERROR_MESSAGE = "";

	public static final String FIRST_NAME_ERROR_MESSAGE = "";

	public static final String FAMILY_NAME_KANA_ERROR_MESSAGE = "";

	public static final String FIRST_NAME_KANA_ERROR_MESSAGE = "";

	public static final String EMAIL_ERROR_MESSAGE = "";

	public static final String USER_ID_ERROR_MESSAGE = "";

	public static final String PASSWORD_ERROR_MESSAGE = "";

	public static final String TEL_NUMBER_ERROR_MESSAGE = "";

	public static final String USER_ADDRESS_ERROR_MESSAGE = "";


}
