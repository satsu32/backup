/**
 * 
 */
/**
 * @author internousdev
 *
 */
package com.internousdev.yataberyouhin.util;