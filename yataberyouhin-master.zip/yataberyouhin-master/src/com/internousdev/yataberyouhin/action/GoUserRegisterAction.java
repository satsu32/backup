package com.internousdev.yataberyouhin.action;

import com.opensymphony.xwork2.ActionSupport;

public class GoUserRegisterAction extends ActionSupport {
	public String execute() {
		return SUCCESS;
	}
}
