package com.internousdev.yataberyouhin.action;
import com.opensymphony.xwork2.ActionSupport;

public class GoHomeAction extends ActionSupport {

	public String execute() {
		String result = SUCCESS;
		return result;

	}
}