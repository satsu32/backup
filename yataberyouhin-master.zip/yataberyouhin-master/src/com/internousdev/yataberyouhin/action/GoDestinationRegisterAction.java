package com.internousdev.yataberyouhin.action;

import com.opensymphony.xwork2.ActionSupport;

public class GoDestinationRegisterAction extends ActionSupport {
	public String execute() {
		return SUCCESS;
	}
}
