/**
 * 
 */
/**
 * @author internousdev
 *
 */
package com.internousdev.yataberyouhin.dao;